package _210_260.Aufgaben;

public class _010_EinmaligesInList {
    public static void main(String[] args) {
//        # Einmaliges in einer Liste
//#
//# Schreibe eine Funktion, die eine ArrayList mit neun Zahlen befüllt.
//# Dabei sollen vier Zahlen doppelt vorkommen
//# und eine Zahl nur einmal.
//#
//# Mische dann die ArrayList mit eine integrierten Funktion die du noch finden musst
//#
//# Schreibe dann eine Methode, die aus dieser ArrayList die Zahl findet,
//# die nur einmal vorkommt.
    }
}
