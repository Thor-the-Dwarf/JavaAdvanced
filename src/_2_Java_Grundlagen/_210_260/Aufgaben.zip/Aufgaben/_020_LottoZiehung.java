package _210_260.Aufgaben;

public class _020_LottoZiehung {
    public static void main(String[] args) {
//        # Lottoziehung
//#
//# Schreibe ein Programm,
//# das sechs verschiedene Lottozahlen (6 aus 49) zieht
//# und in einem Array abspeichert.
//# Gebe danach den Tupel aus
    }
}
