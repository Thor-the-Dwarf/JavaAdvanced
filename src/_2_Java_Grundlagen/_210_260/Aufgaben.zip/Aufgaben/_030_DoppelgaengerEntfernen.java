package _210_260.Aufgaben;

public class _030_DoppelgaengerEntfernen {
    public static void main(String[] args) {
//        # Doppelgänger entfernen
//#
//# Entferne die Doppelgänger aus einer ArrayList von Zahlen
//# (z. B. aus [1, 2, 3, 2, 7, 3, 9]).
//# Die Ergebnisliste soll aufsteigend sortiert sein.
    }
}
