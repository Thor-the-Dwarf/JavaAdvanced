package _210_260.Aufgaben.BonusAufgaben;

public class _150_CaesarChiffreBruteforcen {

    public static void main(String[] args) {

        /*
         * Cäsar-Chiffre bruteforcen
         *
         * Schreibe ein Programm das alle möglichen Lösungen
         * eines Cäsar-chiffrierten Strings ausgibt.
         *
         * Was bedeutet "vxumxgssokxkt sginz yvgyy"?
         *
         * Wer Cäsar-Chiffre nicht kennt: https://de.wikipedia.org/wiki/Caesar-Verschlüsselung
         */

    }
}
